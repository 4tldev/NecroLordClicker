using UnityEngine;
using UnityEngine.UI;

public class UI_MinionPurchaseButton : MonoBehaviour
{
    // TODO this is bad code we should just fire off an event and have a manager listen for the onPurchaseButtonClicked
    [SerializeField] private Player _player;

    private Button btn;
    private UI_MinionPurchaseRow minionPurchaseRow;


    void Start()
    {
        btn = GetComponent<Button>();
        _player = FindAnyObjectByType<Player>();
        minionPurchaseRow = GetComponentInParent<UI_MinionPurchaseRow>();
    }

    public void BuyMinions(Player player)
    {
        if (UI_MinionPurchaseToggleHandler.Instance.amountToBuy == AMOUNT_TO_BUY.BUYMAX) 
        {
            BigNumber maxAffordable = MinionPurchaseCalculator.GetMaxAffordable(minionPurchaseRow.minionListEntry.data.baseCost,
                 minionPurchaseRow.minionListEntry.data.purchaseMultiplier, minionPurchaseRow.minionListEntry.amountOwned, _player.Souls);

            player.MinionPurchaseManager.TryBuyMax(minionPurchaseRow.minionListEntry, maxAffordable);
        }


        player.MinionPurchaseManager.TryBuyMinions(minionPurchaseRow.minionListEntry, UI_MinionPurchaseToggleHandler.Instance.purchaseAmount);
    }

    //public void TryBuyMinions()
    //{
    //    BigNumber amountToBuy = new BigNumber(0);

    //    switch (UI_MinionPurchaseToggleHandler.Instance.amountToBuy)
    //    {
    //        case AMOUNT_TO_BUY.ONE:
    //            amountToBuy = new BigNumber(1);
    //            break;
    //        case AMOUNT_TO_BUY.TEN:
    //            amountToBuy = new BigNumber(10);
    //            break;
    //        case AMOUNT_TO_BUY.ONEHUNDRED:
    //            amountToBuy = new BigNumber(100);
    //            break;
    //        case AMOUNT_TO_BUY.BUYMAX:
    //            amountToBuy = _player.MinionPurchaseManager.Get
    //            break;
    //    }





    //    if (!UI_MinionPurchaseToggleHandler.Instance.isBuyMax)
    //    {
    //        _player.MinionPurchaseManager.TryBuyMinions(minionPurchaseRow.minionListEntry, amountToBuy);
    //    }

    //    _player.MinionPurchaseManager.TryBuyMax(minionPurchaseRow.minionListEntry, amountToBuy);
    //}
}
