using UnityEngine;

public class GameManager : PersistentSingleton<GameManager> { }

