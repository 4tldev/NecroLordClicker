using System;
using UnityEngine;

public class LordPurchaseManager : MonoBehaviour
{
    private Player player;

    private void Awake()
    {
        player = GetComponent<Player>();
    }

    public void TryBuyLord(Player player, SO_UndeadMinionData minionData, SO_LordData lordData) 
    {
        //check to see if the player has enough of the correct minion type to purchase the lord

        foreach (var item in player.MinionManager.UndeadMinions) 
        {
            if (item.data == minionData)
            {
                if (item.amountOwned >= lordData.baseCost)
                {
                    Lord lordToAdd = new Lord();
                    player.LordManager.AddLord(lordToAdd);
                }
                else
                {
                    Debug.Log($"You don't have the required amount of {item.data.name}s! You need {lordData.currentCost} but you only have {item.amountOwned}");
                }

                break; // breaks the loop once we have found the correct data
            }
            else 
            {
                throw new Exception($"Could not locate {item.data.name} in list of minions"); // should never get this
            }
        }
    }
}
