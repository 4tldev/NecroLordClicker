using UnityEngine;
using UnityEngine.UI;

public class UI_BuyLordButton : MonoBehaviour
{
    private Button btn;
    [SerializeField]private Player _player;
    private SO_LordData activeLordToBuy;

    private void Awake()
    {
        btn = GetComponent<Button>();
    }

    private void Start()
    {
        
    }

    

    public void BuyLord() 
    {
        _player.LordPurchaseManager.TryBuyLord(_player, activeLordToBuy,);
    }
}
