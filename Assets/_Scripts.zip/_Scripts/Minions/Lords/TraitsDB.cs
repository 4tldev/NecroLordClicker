using NUnit.Framework;
using System.Collections.Generic;
using UnityEngine;

public class TraitsDB : MonoBehaviour
{
    public static List<Trait> TraitDB = new List<Trait>();
    public void Start()
    {
        Trait PH_willOfTheGrave = new Trait("Will of the Grave",
            "Grants a % increase modifier to souls per second",
            UPGRADETYPE.SOULS_PER_SECOND,
            .10f,
            .20f);
        TraitDB.Add(PH_willOfTheGrave);

        Trait PH_soulbindSigil = new Trait("Soulbind Sigil",
            "Grants a # increase to souls per click",
            UPGRADETYPE.SOULS_PER_CLICK,
            2f,
            5f);
        TraitDB.Add(PH_soulbindSigil);

        Trait PH_unrestingFlame = new Trait("Unresting Flame",
            "Purchase cost reduction",
            UPGRADETYPE.PURCHASE_COST_REDUCTION,
            .10f,
            .20f);
        TraitDB.Add(PH_unrestingFlame);
    }

    public static Trait GetTrait() 
    {
        int r = Random.Range(0, TraitDB.Count);

        return TraitDB[r];
    }

    
}
