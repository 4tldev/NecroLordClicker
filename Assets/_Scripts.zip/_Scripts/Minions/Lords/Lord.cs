using System.Collections.Generic;
using UnityEngine;

public class Lord : MonoBehaviour
{
    private SO_LordData _lordData;
	private List<Trait> _traits;

	public SO_LordData LordData => _lordData;
    [SerializeField] public List<Trait> Traits => Traits;


    public Lord()
	{
		//Generate Name
		_lordData.name = RandomNameGenerator.GenerateName();

		// Generate Random Leader Skill

		// Generate Traits
		int r = Random.Range(1, 3);
		for (int i = 0; i < r; i++) 
		{
			_traits.Add(TraitsDB.GetTrait());
		}
	}
}
