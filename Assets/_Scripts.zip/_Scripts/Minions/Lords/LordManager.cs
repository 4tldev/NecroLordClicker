using System.Collections.Generic;
using UnityEngine;

public class LordManager : MonoBehaviour
{

    private List<Lord> _lords;

    public List<Lord> Lords => _lords;


    public void AddLord(Lord lord)
    {
        _lords.Add(lord);
    }
}
