using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.UI;

public class UI_LordTypeDropdown : MonoBehaviour
{
    [SerializeField] public TMP_Dropdown lordTypeDropdown;
    [SerializeField] public Player Player;
    private List<string> optionsList = new List<string>();
    public SO_VoidEventChannel onLordDropdownValueChanged;
    public string selectedOption;

    public static UI_LordTypeDropdown Instance { get; private set; }

    void Start()
    {
        if (lordTypeDropdown == null)
        {
            Debug.LogError("Lord Type Dropdown is not assigned!");
            return;
        }

        foreach (var minion in Player.MinionManager.UndeadMinions) 
        {
            optionsList.Add(minion.data.name);
            Debug.Log($"Added {minion.data.name} to the Lord Drop Down Menu!");
        }

        lordTypeDropdown.ClearOptions(); // Wipe any existing entries
        lordTypeDropdown.AddOptions(optionsList); // Add new list of entries
    }

    void Update()
    {
        //TODO create an event to check if the player added new minion type and then refresh
        // currently the list is serialized but it should change in the future
    }

    //listeners
    void OnEnable()
    {
        lordTypeDropdown.onValueChanged.AddListener(OnDropdownValueChanged);
    }

    void OnDisable()
    {
        lordTypeDropdown.onValueChanged.RemoveListener(OnDropdownValueChanged);
    }

    void OnDropdownValueChanged(int index)
    {
        selectedOption = lordTypeDropdown.options[index].text;
        Debug.Log("Selected option: " + selectedOption);
        onLordDropdownValueChanged?.Raise();
    }

    
}
