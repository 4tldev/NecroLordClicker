public enum MINIONTYPE 
{
    ZOMBIE,
    SKELETON,
    POLTERGEIST,
    MUMMY,
    BANSHEE,
    VAMPIRE,
    GHOSTCAT
}